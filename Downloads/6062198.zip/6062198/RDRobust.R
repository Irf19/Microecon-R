library(rdrobust)
dta <- data.frame(X=c(1,2,3,4,5,6),
                Y=c(2,4,6,8,10,12))
l <- lm(Y~X, data = dta)
summary(l)


rd_model <- rdrobust(Y~X, data = dta)


x<-runif(1000,-1,1)
y<-5+3*x+2*(x>=0)+rnorm(1000)
rdrobust(y,x)
