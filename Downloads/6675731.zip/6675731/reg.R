# latihan1
# hubungan antara class size dan test score
CS <- c(23, 19, 30, 22, 23, 29, 35, 36, 33, 25)
TS <- c(430, 430, 333, 410, 390, 377, 325, 310, 328, 375)
D <- data.frame(CS,TS)

shapiro.test(D$CS)
plot(D)

# cari mean, variance dan standard deviation dari test scores
mean(TS)
var(TS)
sd(TS)

# korelasi cs dan ts
cor(CS,TS)
summary(D)

# Simple Linear Regression
library(tidyverse)

lm(TS~CS)
summary(lm(TS~CS))

# contoh 2 SLR
install.packages("datarium")
library(datarium)
datarium::marketing
view(marketing)
summary(marketing)
attach(marketing)
sales1 <- lm(sales~.,data = marketing)
summary(sales1)
# abline
plot(youtube,sales,
     col=c("blue", "green"),
     xlab = "youtube", 
     ylab = "sales")
abline(lm(sales~youtube), col="red")


install.packages("haven")
library(haven)
# upload data commuter ~ from base
attach(data_commuter)
summary(data_commuter)
# rename variabel
names(data_commuter)
names(data_commuter)[names(data_commuter) == "A.1"] <- "Gender"
names(data_commuter)[names(data_commuter) == "A.2"] <- "Umur"
names(data_commuter)[names(data_commuter) == "A.3"] <- "Status Perkawinan"
names(data_commuter)
# dan seterusnya

# cek data kosong
anyNA(data_commuter)

# statistik deskriptif
summary(data_commuter)
install.packages("pastecs")
library(pastecs)
stat.desc(data_commuter)

# uji hipotesis
# test the null hypothesis that the mean of the "D4" data 
# is equal to 200000 against the alternative hypothesis that it is not equal to 2000000
t.test(data_commuter$D.4, mu= 2000000)
# note mu adalah population mean
# p.value kurang alpha 0.05, maka hnull tolak/terima?

# regresi sederhana
lm(D.4~A.4)
summary(lm(D.4~A.4))

lm(B.1~D.4)  
summary(lm(B.1~D.4))

# regresi logistik
library(tidyverse)
install.packages("mlbench")
library(mlbench)
data("PimaIndiansDiabetes2", package = "mlbench")
model <- glm( diabetes ~., data = PimaIndiansDiabetes2, family = binomial)
summary(model)
