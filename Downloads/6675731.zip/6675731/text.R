#contoh data
library(tidytext)
load(url("https://osf.io/dvrhc/download"))
head(trumptweets$text)

#Thematic Analysis (the meaning behind the words people use)
#Sentiment Analysis
require(sentimentr)
sentiment('sentiment is super boring')
sentiment('I hate sentiment analysis')
sentiment('Sentiment analysis is super fun')
sentiment('What a great car. It stopped working after a week')
#The sentiment column reflects a number from -1 to +1 
#that is associated with the negative or positive valence of a particular comment.

A <-  c("Will you marry me?", "Oh, you're breaking up with me...")
sentiment (A)

require(SentimentAnalysis)
sen <- analyzeSentiment("Yeah, this was a great football match for the Man Utd team!")
#convert to binary & QDAP dictionary
convertToBinaryResponse(sen)$SentimentQDAP

data <- c("This is good",
               "This is bad",
               "This is inbetween")
convertToDirection(analyzeSentiment(data)$SentimentQDAP)

