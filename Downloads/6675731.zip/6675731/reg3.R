CS <- c(23, 19, 30, 22, 23, 29, 35, 36, 33, 25)
TS <- c(430, 430, 333, 410, 390, 377, 325, 310, 328, 375)
D <- data.frame(CS,TS)
shapiro.test(D$CS)
shapiro.test(D$TS)
plot(D)

mean(TS)
var(TS)
sd(TS)

cor(TS,CS)
summary(D)

#simple linear reg
library(tidyverse)
lm(TS~CS)
summary(lm(TS~CS))

sales1 <- lm(sales~.,data = marketing)
summary(sales1)


names(data_commuter)[names(data_commuter)=="A.1"] <- "Gender"
names(data_commuter)[names(data_commuter)=="A.2"] <- "Usia"
names(data_commuter)

#uji hipotesis
t.test(data_commuter$D.4,mu=2000000)
lm(D.4~A.4)
summary(lm(D.4~A.4))

#kuis kecil
#coba lakukan regresi dengan data sembarang atau pakai data commuter, atau data di posit
