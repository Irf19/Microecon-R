
#contoh kasus:
#Variabel 
#X : Menggunakan pinjol atau tidak (0 = tidak memakai, 1 = Memakai) 
#Y : Tingkat perkembangan usaha ...(satuan pengukuran)(1 = sangat buruk, 2 = buruk, 3 = stagnan, 4 = baik, 5 = sangat baik) 
# Data Bebas Buatan 

X <- c(0,0,0,0,1,2,2,2,0,2,2,0,0,2)
Y <- c(5,5,4,4,2,1,2,3,4,1,2,1,2,3)
#WDYT
D <- data.frame(X,Y)
Dl <- lm(Y~X)
summary(Dl)



#def.op
#GRE: Graduate Record Exam scores (nilai skor GRE terakhir)
#GPA: Grade Point Average (nilai IPK)
#rank: institution prestige (1=the highest; 4=the lowest)
#admin: status penerimaan mhs
#

gre <- c(520, 620, 540, 740, 660, 600, 680, 760)
gpa <- c(3.1, 2.9, 2.2, 3.7, 3.3, 3.5, 3.0, 3.9)
rank <- c(3,3,4,4,1,2,3,2)
admit <- c(0, 1, 1, 1, 0, 1, 0, 1)
ldata <- data.frame(admit, gre, gpa, rank)
mylogit <- glm(admit ~ gre + gpa + rank, data = ldata, family = "binomial")
summary(mylogit)

#ubah dan run ulang mulai baris 6
ldata$rank <- factor(ldata$rank)

#bagaimana jika data r dirubah?
r <- c(3, 1, 4, 1, 2, 1, 2, 3)

#data Titanic
datarium::titanic.raw
View(titanic.raw)
titanic.raw$Sex <- as.factor(titanic.raw$Sex)
Tlogit <- glm(Survived~Sex, data = titanic.raw, family = "binomial")
summary(Tlogit)


