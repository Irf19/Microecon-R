install.packages("haven")
library(haven)
# upload data commuter ~ from base
attach(data_commuter)
summary(data_commuter)
# rename variabel
names(data_commuter)
names(data_commuter)[names(data_commuter) == "A.1"] <- "Gender"
names(data_commuter)[names(data_commuter) == "A.2"] <- "Umur"
names(data_commuter)[names(data_commuter) == "A.3"] <- "Status Perkawinan"
names(data_commuter)
# dan seterusnya

# cek data kosong
anyNA(data_commuter)

# statistik deskriptif
summary(data_commuter)
install.packages("pastecs")
library(pastecs)
stat.desc(data_commuter)

# uji hipotesis
# test the null hypothesis that the mean of the "D4" data 
# is equal to 200000 against the alternative hypothesis that it is not equal to 2000000
t.test(data_commuter$D.4, mu= 2000000)
# note mu adalah population mean
# p.value kurang alpha 0.05, maka hnull tolak/terima?

# regresi sederhana
lm(D.4~A.4)
summary(lm(D.4~A.4))

lm(B.1~D.4)  
summary(lm(B.1~D.4))

# regresi logistik
library(tidyverse)
install.packages("mlbench")
library(mlbench)
data("PimaIndiansDiabetes2", package = "mlbench")
model <- glm( diabetes ~., data = PimaIndiansDiabetes2, family = binomial)
summary(model)
