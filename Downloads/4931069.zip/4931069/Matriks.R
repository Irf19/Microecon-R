print("Hello Math Econ R")
#Matriks
  #Membuat Matriks
    #vektor numerik
G1 <- c(7,1)
G2 <- c(3,5)
G3 <- c(4,6)
A <- cbind(G1,G2,G3)
A

#memberi nama row
row.names(A) <- c("K1","K2") 
A

#memilih baris atau kolom
A[2,]
A[1,]

t(A)[2,]
t(A)[1,]

#cek Matriks
is.matrix(t(A))
is.vector(t(A))

#Operasi Matriks
  #penjumlahan
e1 <- c(3,3,2)
e2 <- c(3,2,3)
e3 <- c(2,1,2)
E <- cbind(e1,e2,e3)
E

f1 <- c(10,10,12)
f2 <- c(12,10,12)
f3 <- c(15,15,10)
F <- cbind(f1,f2,f3)
F

G <- E+F
G
  #pengurangan
I <- F-E
I


#Transpose Matriks
t(A)

c1 <- c(9,2)
c2 <- c(-1,0)
C3 <-cbind(c1,c2)
C3
t(C3)

#Perkalian Matriks
  #perkalian skalar
j1 <- c(3,0)
j2 <- c(-1,5)
J<-cbind(j1,j2) 
J
K <- J*7
K

j3 <- c("a","b")
j4 <- c("c","d")
L <- cbind(j3,j4)
L
#note: perkalian matriks (tidak bisa digunakan untuk perkalian tipe data number dan character)

#persamaan linear dan matriks
a1 <- c(5,6)
a2 <- c(3,-2)
A3 <- cbind(a1,a2)
A3

#determinan
det(A3)

a4 <- c(30,8)
a5 <- c(3,-2)
A4 <- cbind(a4,a5)
A4
det(A4)

a6 <- c(5,6)
a7 <- c(30,8)
A5 <- cbind(a6,a7)
A5
det(A5)

#x1 dan x2
det(A4)/det(A3)
det(A5)/det(A3)

#invers matriks
i1 <- c(5,0)
i2 <- c(2,1)
I3<- cbind(i1,i2)
I3
I3i <- solve(I3)
I3i
print(I3%*%I3i)

#alternatif membuat matriks
matrix(1:50,nrow=10,ncol=5)

I<-matrix(c(3,2,1,2,2,2),ncol = 2, byrow = T)
I
J<-matrix(c(2,2,2,3,3,3),ncol = 3, byrow = T)
J
K<-I%*%J
K







Kprint("Hello Math Econ R")
#Matriks
#Membuat Matriks
#vektor numerik
G1 <- c(7,1)






