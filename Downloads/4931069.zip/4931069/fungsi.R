# soal latihan
# f(x)= 2x+1
# hitung f(0), f(0.5),f(1),f(2),f(3),f(4)

f <- function(x){
  2*x+1
}
f(0)
f(1)
f(2)

x <- c(-Inf, Inf)

  