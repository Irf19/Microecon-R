install.packages("lpSolve")
library(lpSolve)

#Setting the coefficients of decision variables
objective.in <- c(25,20)

#Constraint Matrix
const.mat <- matrix(c(20,12,5,5),nrow = 2, byrow = TRUE)

#defining constraints
const.time = 540
const.resour = 2000

#RHS (right hand side) for constraints
const.rhs <- c(const.time,const.resour)

#Direction for constraints
const.dir=c("<=","<=")

#Finding the optimum solution
opt <- lp(direction = "max",objective.in,const.mat,const.dir,const.rhs)


#Objective values of x and y
opt$solution

#Value of objective function at optimal point
opt$objval
