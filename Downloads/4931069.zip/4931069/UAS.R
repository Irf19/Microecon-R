

#jawab
#membuat parameter





obj.fun <- c(40,90)
constr <- matrix(c(35,25,5,10,1,1),ncol = 2,byrow = TRUE)
const.dir <- c("<=","<=",">=")
rhs <- c(2900,755,95)

#solving model
prod.sol <- lp("max",obj.fun,constr,const.dir,rhs,compute.sens = TRUE)

#output
#objective value
prod.sol$objval

#variable value
prod.sol$solution