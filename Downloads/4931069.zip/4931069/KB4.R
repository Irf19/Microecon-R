#persamaan linear dan matriks
A <- matrix(c(2,-1,1,1,1,1,0,1,-1),ncol = 3,byrow = TRUE)
A
det(A)

B <- matrix(c(3,-1,1,2,1,1,-1,1,-1),ncol = 3,byrow = TRUE)
B
det(B)
x <- det(B)/det(A)
x

C <- matrix(c(2,3,1,1,2,1,0,-1,-1),ncol = 3,byrow = TRUE)
C
det(C)
y <- det(C)/det(A)
y





#define parameters

obj.fun <- c(30,80)
constr <- matrix(c(30,20,5,10,1,1),ncol = 2,byrow = TRUE)
const.dir <- c("<=","<=",">=")
rhs <- c(2700,855,95)

#solving model
prod.sol <- lp("max",obj.fun,constr,const.dir,rhs,compute.sens = TRUE)

#output
#objective value
prod.sol$objval

#variable value
prod.sol$solution