install.packages("lpSolve")
library(lpSolve)

#membuat parameter
obj.fun <- c(20,60)
constr <- matrix(c(30,20,5,10,1,1),ncol = 2,byrow = TRUE)
const.dir <- c("<=","<=",">=")
rhs <- c(2700,850,95)

#solving model
prod.sol <- lp("max",obj.fun,constr,const.dir,rhs,compute.sens = TRUE)

#output
#objective value
prod.sol$objval

#variable value
prod.sol$solution
#stop

#duals constrain
prod.sol$duals






