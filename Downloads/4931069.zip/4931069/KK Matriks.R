#KuisKecil-Matriks
#Nama
#NIM

#1. Buat matriks (ordo 2x2, 2x3, 3x2, 3x3)
#2. Cari determinan salah satu matriks diatas
#3. Cari invers matriks tersebut
#4. Transpose matriks tersebut
#5. Buat contoh perkalian matriks dengan skalar
#6. Buat contoh perkalian matriks dengan matriks

#Save hasil sebagai pdf
#pilih File, print, save as pdf
#kirim via ms teams untuk pertemuan hari ini

D <- matrix(c(3,3,3,1,2,3,5,4,8),ncol = 3,byrow = T)
D
