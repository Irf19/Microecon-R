#latihan Multiple Reg 648
> #input data
  > X1 <- c(100,50,100,100,50,80,75,65,90,90)
  > X2 <- c(4,3,4,2,2,2,3,4,3,2)
  > Y <- c(9.3,4.8,8.9,6.5,4.2,6.2,7.4,6.0,7.6,6.1)
  > lm (Y~X1+X2)
  summary(lm (Y~X1+X2)
          
          
  dat <- mtcars
  library(ggplot2)
  ggplot(dat, aes(x = wt, y = mpg)) +
            +   geom_point() +
            +   labs(
              +     y = "Miles per gallon",
              +     x = "Car's weight (1000 lbs)"
              +   ) +
            +   theme_minimal()
          > model <- lm(mpg ~ wt, data = dat)
          > summary(model)