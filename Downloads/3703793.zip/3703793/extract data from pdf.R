library(pdftools)
library(readr)
library(plyr)

tab1 <- pdf_text("Tugas Chapter 10.pdf") %>%
  read_lines()
tab2 <- tab1[1:27] %>%
  str_squish() %>%
  strsplit(split = " ")

tab3 <- ldply(tab2)
view(tab3)